#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
#include "Hero.h"

using namespace std;

void Hero::showHealth()
{
	cout << "The hero has " << health << "health";
} 

//int Hero::getHealth() const
//{
//	
//}

void Hero::setHealth(int _health)
{
	if (_health > 0)
		health = _health;
	else health = 0;
}

void Hero::greeting()
{
	cout << "My name is" << name << ", I have "
		<< health << " health";
}

//Magician
void Magician::setMana(int _mana)
{
	if (_mana > 0)
		mana = _mana;
	else mana = 0;
}

void Magician::showHealthMana()
{
	Hero::showHealth();
	 cout << " and" << mana << "mana." << '\n';
}

void Magician::greeting()
{
	Hero::greeting();
	cout << " and I'm a Magician." << '\n';
}

int Magician::identify()
{
	return 1;
}

void Magician::attack(Hero* enemy)
{
	enemy->setHealth(enemy->health - mana);
	setMana(mana - 20);
}

void Warrior::showHealthRage()
{
	Hero::showHealth();
	cout << " and" << rage << " rage." << '\n';
}

void Warrior::greeting()
{
	Hero::greeting();
	cout << " and I'm a Warrior." << '\n';
}

void Warrior::setRage(int _rage)
{
	if (_rage > 0)
		rage = _rage;
	else rage = 0;
}

int Warrior::identify()
{
	return 2;
}

void Warrior::attack(Hero* enemy)
{
	enemy->setHealth(enemy->health - (rage + 10));
	setRage(rage + 20);
}
