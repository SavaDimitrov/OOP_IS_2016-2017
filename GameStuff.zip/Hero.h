#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>
#include <string>

using namespace std;
const int MAX_NAME_LENGTH = 30;


class Hero {
public:
	char name[MAX_NAME_LENGTH];
	int health;


	Hero(int _health, char _name[MAX_NAME_LENGTH]) {
		health = _health;
		strcpy(name, _name);
	}
	
	void showHealth();
	
	/*int getHealth() const {
		return this->health;
	}*/
	void setHealth(int);

	virtual void greeting() = 0;

	virtual int identify() = 0;
	virtual void attack(Hero* enemy) = 0;
};

class Magician :public Hero {
	int mana;

public:
	Magician(int newHealth, char newName[MAX_NAME_LENGTH], int newMana = 200) : Hero(newHealth, newName), mana(newMana) {}
	
	void setMana(int);

	void showHealthMana();
	void greeting();

	int identify();
	void attack(Hero*);
};

class Warrior :public Hero {
	int rage;

public:
	Warrior(int newHealth, char newName[MAX_NAME_LENGTH], int newRage = 0):Hero(newHealth, newName), rage(newRage){}

	void showHealthRage();
	void greeting();
	void setRage(int);

	int identify();
	void attack(Hero*);

};