#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "Hero.h"

using namespace std;
const int MAX_HEROES = 6;


int main() {

	Hero* heroes[MAX_HEROES];

	Warrior warr(120, "Warr");
	heroes[0] = &warr;
	Warrior warr1(120, "Warr1");
	heroes[1] = &warr1;
	Warrior warr2(120, "Warr2");
	heroes[2] = &warr2;
	Magician mage(100, "Mage");
	heroes[3] = &mage;
	Magician mage1(100, "Mage1");
	heroes[4] = &mage1;
	Magician mage2(100, "Mage2");
	heroes[5] = &mage2;
	
	while (true) {
		for (int i = 0; i < MAX_HEROES; i++)
		{
			if (heroes[i]->identify() == 2) {
				if (heroes[i]->identify() == 2) {

					heroes[i]->attack((Warrior*)heroes[i + 1]);
				}
				else heroes[i]->attack((Magician*)heroes[i + 1]);
			}
			else {
				if (heroes[i]->identify() == 2) {

					heroes[i]->attack((Warrior*)heroes[i + 1]);
				}
				else heroes[i]->attack((Magician*)heroes[i + 1]);
			}

			if (i == MAX_HEROES - 1) {
				break;
			}
		}
	}

	for (int i = 0; i < MAX_HEROES; i++)
	{
		heroes[i]->greeting();
	}

	system("pause");
	return 0;
}