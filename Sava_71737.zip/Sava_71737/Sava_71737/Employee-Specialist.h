#pragma once
#include <iostream>
#include <string>

using namespace std;

const int ID_LENGTH = 10;
const int SPEC_NAME_LENGTH = 32;

class Employee {
	char* name;
	char* adress;
	char ID[ID_LENGTH];
	char* department;
	double salary;

	void fireEmployee() {
		delete name;
		name = nullptr;
		delete adress;
		adress = nullptr;
		delete department;
		department = nullptr;
	}

public:
	Employee();
	Employee(char*, char*, char, char*, double);
	virtual ~Employee();

	double getSalary() const;

	void setName(char* newName);
	void setAdress(char* newAdress);
	void setDepartment(char* newDepartment);

};

class Specialist :public Employee {
	char* spec;

	void deleteSpec() {
		delete spec;
		spec = nullptr;
	}

public:
	Specialist() :Employee() {}
	Specialist(char* _name, char* _adress, char _ID[ID_LENGTH], char* _department, double _salary, char* _spec[SPEC_NAME_LENGTH]) :
		Employee(_name, _adress, _ID, _department, _salary) {

		//setSpec()..

		strcpy(spec, _spec[SPEC_NAME_LENGTH]);
	}

	~Specialist();

	char* getSpec() const;

	void setSpec(char* newSpec);
};

//void formAFirm(Employees** employee, int <spec1>NumEmp, int <spec2>NumEmp, int <spec3>NumEmp, ...){
// 1) obhojdame celiq masiv i proverqvame dali ima nujniq broi specialisti
// 2) ako ima tochen broi za vs ne proverqvame zaplati, ako sa > proverqvame zaplatite, < false }