#pragma once
#include <iostream>
#include <string>
#include "Employee-Specialist.h"

using namespace std;

class DepartmentLeader :public Specialist {
	Employee** employees;
	char* department;

public:

	DepartmentLeader() :Specialist() {}
};