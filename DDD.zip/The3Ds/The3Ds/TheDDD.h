#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>

using namespace std;

int const DEFAULT_NAME_LENGTH = 5;
int const DEFAULT_FACULTY_NAME_LENGTH = 4;
int const DEFAULT_AGE = 24;

class Person {
protected:
	char* name;
	int age;

	/*void remove() {
		delete name;
		name = nullptr;
	}
*/
public:

	//ako imame konstruktori s parametri, v posledniq class
	//trqbva da kajem koi konstruktor na bashtiniq class
	//iskame da izvikame: Ta(int x): Faculty(x), Student(x), Person(x)!

	Person(){
		name = new char[DEFAULT_NAME_LENGTH];
		strcpy(name, "I am");
		age = DEFAULT_AGE;

		cout << "Person created." << '\n';
	}

	virtual ~Person() {
		//remove();
		delete name;
		name = nullptr;

		cout << "Person destroyed." << '\n';
	}

	virtual void print() = 0;
};

class Faculty : virtual public Person {
	char* facultyName;
	
	/*void removeFaculty() {
		delete facultyName;
		facultyName = nullptr;
	}*/
public:

	Faculty() :Person() {
		facultyName = new char[DEFAULT_FACULTY_NAME_LENGTH];
		strcpy(facultyName, "FMI");

		cout << "Faculty created." << '\n';
	}

	~Faculty() {
		//removeFaculty();
		delete facultyName;
		facultyName = nullptr;

		cout << "Faculty destroyed." << '\n';
	}

	void print() {
		cout << "Person name: " << this->name << '\n'
			<< "Person age: " << this->age << '\n'
			<< "Faculty: " << this->facultyName << '\n';
	}
};

class Student : virtual public Person {
	char ID[10];

public:
	Student() :Person() {
		//Faculty::Faculty();
		strcpy(ID, "931010****");

		cout << "Student created." << '\n';
	}

	void print() {
		cout << "ID: " << this->ID << '\n';
	}
};

class TA :public Faculty, public Student {
public:
	TA() :Faculty(), Student() {
		cout << "TA created." << '\n';
	}
	~TA() {
		cout << "TA destroyed." << '\n';
	}

	void print() {
		//Faculty::print();
		//Student::print();
	}
};