#define _CRT_SECURE_NO_WARNINGS
#include "TheDDD.h"
#include <iostream>

using namespace std;

int main() {

	TA ta;
	ta.~TA();

	cout << '\n' << '\n';

	TA* ta1 = &ta;
	ta1->print();

	system("pause");
	return 0;
}