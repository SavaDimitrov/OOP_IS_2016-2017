#pragma once
#include <iostream>


class Employee {
	char* name;

public:
	Employee();
	Employee(char*);
	~Employee();

	char* getName() const;
	void setName(char*);

	Employee& operator=(const Employee & other);

};