#include <iostream>
#include "Employee.h"
#include <string.h>

Employee::Employee():name(nullptr) {}


Employee::Employee(char* _name) : name(nullptr) {
	this->setName(_name);
}

void Employee::setName(char* _name) {
	size_t  length = strlen(_name) + 1;
	this->name = new char[length];
	strcpy(this->name, _name);
}

char* Employee::getName() const {
	return this->name;
}

Employee::~Employee() {
	delete name;
}

Employee& Employee::operator=(const Employee &other) {
	if (this != &other) {

	}
	return *this;
}