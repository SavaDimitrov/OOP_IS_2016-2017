#include <iostream>

using namespace std;

class theBigFour {


public:
	theBigFour() {};
	theBigFour(const theBigFour& other) {};
	~theBigFour();
	theBigFour& operator=(const theBigFour &other);
};


int main()
{


	system("pause");
	return 0;
}