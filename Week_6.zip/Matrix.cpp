#include <iostream>
#include "Point3D.h"
using namespace std;

class Matrix {

public:
	Point** points;
	int rows;
	int cols;

	Matrix():points(nullptr){
		rows = 0;
		cols = 0;
	}
	Matrix(int _rows, int _cols) {
		points = new Point*[_rows]; //1
		for (int i = 0; i < _rows; i++)
		{
			points[i] = new Point[_cols]; //2
			for (int j = 0; j < _cols; j++)
			{
				points[i][j] = Points();//3
			}
		}
		
	}

	
	~Matrix() {
		dealLoc();
	}
	Matrix(const Matrix &other) {

	}
	Matrix& operator=(const Matrix &other) {
		if (this != &other) {
			dealLoc();
			//copyFrom();
		}
		return *this;
	}




	int getRows() const{ return rows; }
	int getCols() const { return cols; }


	void setRows(int newRows) {
		if (newRows > 0) {
			this->rows = newRows;
		}
		else cout << "Error. Rows can't be negative!" << '\n';
	}

	void setCols(int newCols) {
		if (newCols > 0) {
			this->cols = newCols;
		}
		else cout << "Error. Cols can't be negative!" << '\n';
	}

	void dealLoc() {
		for (int i = 0; i < rows; i++)
		{
			delete[] points[i];
		}
		delete points;
	}


};
















int main()
{



	system("pause");
	return 0;
}