#include <iostream>
#include "Doctors.h"
#include "Workers_Students.h"

using namespace std;

int main() {

	Surgeon surg("Someone", 20, "Heart Surgeon");

	cout << surg << '\n';
	cout <<"Chance for success in a surgeory based on the specialization: " 
		<< surg.chanceForSuccess("Heart Surgeon") << "%" << '\n';


	system("pause");
	return 0;
}