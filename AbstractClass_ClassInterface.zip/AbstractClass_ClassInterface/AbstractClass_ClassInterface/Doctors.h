#pragma once
#include <iostream>
#include <string>

using namespace std;

const int NAMES_LENGTH = 101;
const int DEFAULT_YEARS_EXP = 0;
const int YEARS_EXP_MIN = 0;
const int YEARS_EXP_MAX = 40;

class Doctor {
	char name[NAMES_LENGTH];
	int yearsExperience; // 0 - 40

public:

	Doctor() {
		strcpy(this->name, "");
		yearsExperience = DEFAULT_YEARS_EXP;
	}

	Doctor(char* newName, int newYearsExp) {
		strcpy(this->name, newName);
		setYearsExp(newYearsExp);
	}


	int getYearsExp() const { return this->yearsExperience; }

	void setYearsExp(int newYears) {
		if (newYears >= YEARS_EXP_MIN && newYears <= YEARS_EXP_MAX) {
			this->yearsExperience = newYears;
		}
		else cout << "Invalid number for year of experience." << '\n';
	}

	friend ostream& operator<<(ostream& os, const Doctor& doc) {
		os << "Doctor name: " << doc.name << '\n'
			<< "Experience(years): " << doc.yearsExperience << '\n';

		return os;
	}

};

class Surgeon : public Doctor {
	char specialization[NAMES_LENGTH];

public:
	
	Surgeon() : Doctor(){
		
		strcpy(this->specialization, "");
	}

	Surgeon(char* newName, int newYearsExp, char* newSpec) : Doctor(newName, newYearsExp) {
		strcpy(this->specialization, newSpec);
	}

	double chanceForSuccess(char* spec) {
		int yearsWorking = getYearsExp();

		if (strcmp(this->specialization, spec) == 0)
			return 60 + yearsWorking;
		else
			return 40 + (yearsWorking * (2 / 3));
	}
	
	friend ostream& operator<<(ostream& os, const Surgeon& surg) {
		os << (Doctor)surg;
		os << "Surgeon specialization: " << surg.specialization << '\n';

		return os;
	}
};

class Vet : public Doctor {
	char animalSpec[NAMES_LENGTH];

public:

	Vet() {
		Doctor();
		strcpy(this->animalSpec, "");
	}

	Vet(char* newName, int newYearsExp, char* newAnimalSpec) {
		Doctor(newName, newYearsExp);
		strcpy(this->animalSpec, newAnimalSpec);
	}

	double chanceForSuccess(char* spec) {
		if (strcmp(this->animalSpec, spec) == 0)
			return 50 + (getYearsExp() * (4 / 5));
		else
			return 45 + (getYearsExp() * (3 / 4));
	}


	friend ostream& operator<<(ostream& os, const Vet& vet) {
		os << (Doctor)vet;
		os << "Vet animal specialization: " << vet.animalSpec << '\n';
		return os;
	}
};