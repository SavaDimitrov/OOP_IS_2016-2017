#pragma once
#include <iostream>

using namespace std;

const int NAME_LENGTH = 101;
const int SPEC_NAME_LENGTH = 101;

class Person {
	char name[NAME_LENGTH];
	char lastName[NAME_LENGTH];
	int years;

public:
	void print() {
		cout << "Name: " << name << '\n'
			<< "Last name: " << lastName << '\n'
			<< "Years: " << years << '\n';
	}
};

class Student : public Person {
	char spec[SPEC_NAME_LENGTH];
	double grade;
public:
	void print() {
		Person::print();
		cout << "Spec: " << spec << '\n'
			<< "Grade: " << grade << '\n';
	}
};

class Worker :public Person {
	double salaryPerHour;
	double hoursWorked;
public:
	
	double calculateSalary() {
		return salaryPerHour * hoursWorked;
	}
	
	void print() {
		Person::print();
		cout << "Salary per hour: " << salaryPerHour << '\n'
			<< "Hours worked: " << hoursWorked << '\n'
			<< "Salary for the worked hours: " << calculateSalary() << '\n';
	}
};