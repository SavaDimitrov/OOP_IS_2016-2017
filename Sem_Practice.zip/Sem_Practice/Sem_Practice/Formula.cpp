#include <iostream>

using namespace std;


class Formula {
public:
	virtual double value() const = 0;
	//virtual void print() const = 0;
};

class Constant : public Formula {
	int val;
public:
	Constant(int);
	double value() const;
};


Constant::Constant(int newVal) {
	this->val = newVal;
}

double Constant::value() const {
	return this->val;
}


class BinaryOperation :public Formula {
	Formula* leftArgument;
	Formula* rightArgument;
	char operation;
public:
	BinaryOperation(Formula* lard, Formula* rarg, char op) {
		leftArgument = lard;
		rightArgument = rarg;
		operation = op;
	}

	double value() const {
		switch (operation) {
		case '+': return leftArgument->value() + rightArgument->value(); break;
		case '-': return leftArgument->value() - rightArgument->value(); break;
		case '/': return leftArgument->value() / rightArgument->value(); break;
		default: return leftArgument->value() * rightArgument->value(); break;
		}
	}
};


int main() {

	Constant a(2);
	Constant b(3);

//	cout << a.value() << '\n';

	BinaryOperation binop(&a, &b, '+');

	Formula *f = &binop;

	cout << f->value() << endl;

	system("pause");
	return 0;
}