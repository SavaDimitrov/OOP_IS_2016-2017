#include <iostream>
#include <string>

using namespace std;

//template <typename T>
//void mySwap(T& left, T& right) {
//	T tmp = left;
//	left = right;
//	right = tmp;
//}
//
//void  testSwap() {
//	int grade = 6;
//	int universal = 42;
//	mySwap<int>(grade, universal); //Pri funkcii moje i bez <int>
//	cout << "grade: " << grade << " universal: " << universal << '\n';
//}
//
//template <typename T>
//void myReverse(T *arr, int size) {
//	for (int i = 0; i < size / 2; i++)
//	{
//		mySwap<int>(arr[i], arr[size - i - 1]);
//	}
//}
//
//void testReverse() {
//	int arr[] = { 1,2,3,4,5,6 };
//	myReverse<int>(arr, 6);
//	for (int i = 0; i < 6; i++)
//	{
//		cout << arr[i] << " ";
//	}
//	cout << endl;
//}
//
//template <typename K, typename V>
//class MyPair {
//	K key;
//	V value;
//public:
//	MyPair(K, V); //mojem da go napishem bez template otgore, tui kato e v class-a i moje bez <K, V>
//				  //ako e otvun pishem 1vo otgore "template <typename K, typename V>" MyPair<K, V>::MyPair(...)
//	K getKey();
//	V getValue();
//	template <typename K, typename V> //tova trqbva da go ima, tui kato operator<< ne prinadleji na class-a ni
//									  //zatova imame template...
//	friend ostream& operator<<(ostream&, MyPair<K, V> const&);
//};
//
//template <typename K, typename V>
//MyPair<K, V>::MyPair(K _key, V _value) {
//	key = _key;
//	value = _value;
//}
//template <typename K, typename V>
//K MyPair<K, V>::getKey() {
//	return key;
//}
//
//template <typename K, typename V>
//V MyPair<K, V>::getValue() {
//	return value;
//}
//
//template <typename K, typename V>
//ostream& operator<<(ostream& os, MyPair<K, V> const& other) //tuk nqmame MyPair<K, V>:: zashtoto operator<< ne prinadleji na nashiq class
//{ 
//	os << "Key: " << "(" << other.key << ", " << other.value 
//		<< ")" << " :Value" << '\n';
//
//	return os;
//}
//
//void testMyPair() {
//	MyPair<double, int> p(3.14, 6);
//	cout << p;
//}
//
//
///*
//Ideq na polimorfizma: Da moje ako imame "slojna" ierarhiq na nasledqvane da dostupvame metodi 
//na opredelen class po ukazatel bez da stavat greshki v tova ot kude dostupva funkciqta.
//*/
//
//class Shape { // tozi class ne e abstrakten!! za da e abstrakten, 
//			 //to trqbva da ima pone edna chisto virtualna funkciq, t.e. = 0;
//protected:
//	int width, height;
//public:
//	Shape(int a = 0, int b = 0) {
//		width = a;
//		height = b;
//	}
//
//	virtual int area() {
//		cout << "Parent class area: " << endl;
//		return 0;
//	}
//};
//
//class Rectangle : public Shape {
//public:
//	Rectangle(int a = 0, int b = 0) :Shape(a, b) {}
//	int area() {
//		cout << "Rectangle class area: " << endl;
//		return (width * height);
//	}
//};
//
//class Triangle : public Shape {
//public:
//	Triangle(int a = 0, int b = 0) :Shape(a, b) {}
//	int area() {
//		cout << "Triangle class area: " << endl;
//		return (width * height / 2);
//	}
//};

template <typename T, typename K, typename V>
class Container {
	T firstEl;
	K secondEl;
	V thirdEl;
public:
	Container(T newFirstEl, K newSecondEl, V newThirdEl) {
		firstEl = newFirstEl;
		secondEl = newSecondEl;
		thirdEl = newThirdEl;
	}

	template <typename T, typename K, typename V>
	friend ostream& operator<<(ostream& os, Container<T,K,V> const& other) {
		os << "First element: " << other.firstEl
			<< "Second element: " << other.secondEl
			<< "Third element: " << other.thirdEl;

		return os;
	}

	V getThird(T _firstEl, K _secondEl) {
		if (_firstEl == firstEl && _secondEl == secondEl) {
			return thirdEl;
		}

		return V(); //VAJNO!!!!! po takuv nachin vrushtame prazen obekt ot nqkakuv tip(kogato e nujno da vurnem neshto)
	}
};

//Second Task
class Fish {
public:
	virtual void lifeOfTheFishes() = 0;
};

class Predator :public Fish {
	int currentTimeStarved;
	int maxStarvingTime;
public:

	void lifeOfTheFishes() {
		deathFromStarving();
	}

	void deathFromStarving() {
		while (true) {
			if (currentTimeStarved == maxStarvingTime) {
				cout << "The fish lived " << currentTimeStarved << " years with no food. The fish is dead sadly. :(" << '\n';
				return;
			}
			else {
				currentTimeStarved += 2;
				cout << "The fish lived " << currentTimeStarved << " years with no food and it is still alive. :O" << '\n';
			}
		}
	}

};

class Prey :public Fish {
	int maxYearsLiving;
	int currentYearsLiving;
public:

	void lifeOfTheFishes() {
		deathFromOldAge();
	}

	void deathFromOldAge() {
		while (true) {
			if (currentYearsLiving == maxYearsLiving) {
				cout << "The fish lived " << currentYearsLiving << " years. The fish is dead sadly. :(" << '\n';
				return;
			}
			else {
				currentYearsLiving++;
				cout << "The current years of the fish are " << currentYearsLiving << " and it is still alive. :O" << '\n';
			}
		}
	}
};

class Aquarium {
	Fish** fishes;
	int cap;
	int size;

	void killFishes() {
		for (int i = 0; i < size; i++)
		{
			for (int i = 0; i < size; i++)
			{
				delete fishes[i];
			}
		}
	}
public:

	Aquarium() {
		cap = 10;
		size = 0;
		fishes = new Fish*[cap];
	}

	~Aquarium() {
		killFishes();
	}
};

int main() {

	//testMyPair();

	/*Shape* ps;

	ps = &Rectangle(2, 3);
	cout << ps->area() << '\n';
	ps = &Triangle(2, 3);
	cout << ps->area() << '\n';*/





	system("pause");
	return 0;
}