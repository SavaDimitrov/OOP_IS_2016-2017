#include "Employee.h"

using namespace std;

Employee::Employee() {
	this->id = 0;
	this->firstName = "";
	this->lastName = "";
	this->salary = 0;
}

Employee::Employee(int _id, char* _firstName, char* _lastName, double _salary) {
	this->setId(_id);
	this->setFirstName(_firstName);
	this->setLastName(_lastName);
	this->setSalary(_salary);
}

Employee::Employee(const Employee& other) {
	this->setId(other.id);
	this->setSalary(other.salary);
	this->setFirstName(other.firstName);
	this->setLastName(other.lastName);
}

int Employee::getID() { return this->id; };
double Employee::getSalary() { return this->salary; }
char* Employee::getfirstName() { return this->firstName; }
char* Employee::getlastName() { return this->lastName; }

void Employee::setId(int newId) {
	if (newId < 0) {
		cout << "Invalid ID number!" << '\n';
	}

	this->id = newId;
}

void Employee::setSalary(double newSalary) {
	if (newSalary < 0) {
		cout << "Invalid salary amount!" << '\n';
	}

	this->salary = newSalary;
}

void Employee::setFirstName(char* newFirstName) {
	if (this->firstName != NULL) {
		delete this->firstName;
	}


	this->firstName = new char[strlen(newFirstName) + 1];
	strcpy(this->firstName, newFirstName);
}

void Employee::setLastName(char* newLastName) {
	if (this->lastName != NULL) {
		delete this->lastName;
	}

	this->lastName = new char[strlen(newLastName) + 1];
	strcpy(this->lastName, newLastName);
}

double Employee::getAnnualSalary() {
	return this->salary * 12;
}

void Employee::raiseSalary(int percent = 20) {
	setSalary(getSalary() + getSalary()*(percent / 100));
}

void Employee::description() {
	cout << "First name: " << this->getfirstName() << '\n';
	cout << "Last name: " << this->getlastName() << '\n';
	cout << "ID: " << this->getID() << '\n';
	cout << "Salary: " << this->getSalary() << '\n';
	cout << "Annual salary: " << this->getAnnualSalary() << '\n';
	this->raiseSalary();
	cout << "Salary after raise: " << this->getSalary() << '\n';
}