#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>

using namespace std;

class Employee {

	int id;
	char* firstName;
	char* lastName;
	double salary;

 public:
	 Employee();
	 Employee(int, char*, char*, double);
	 Employee(const Employee& other);

	 int getID();
	 double getSalary();
	 char* getfirstName();
	 char* getlastName();

	 void setId(int);
	 void setSalary(double);
	 void setFirstName(char*);
	 void setLastName(char*);

	 double getAnnualSalary();
	 void raiseSalary(int);
	 void description();
};